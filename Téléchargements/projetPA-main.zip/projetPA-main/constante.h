#define TAILLE_BLOC 32 
